print('Hello world!')
print('Hello world!')
print('Hello world!')

print('Hello world!')
print('Hello world!')